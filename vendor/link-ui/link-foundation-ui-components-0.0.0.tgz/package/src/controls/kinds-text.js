/**
 * The control kinds as text, so they load without a file system or a
 * bundler. Byte-equal to kinds.lino next to this module;
 * tests/controls/vocabulary.test.js checks that they stay in sync.
 */

/** src/controls/kinds.lino. */
export const CONTROL_KINDS_TEXT = `button: kind
  description 'A pressable control.'
  positional label
  property label string
  property variant
    enum filled tonal outlined text elevated secondary transparent bordered borderless prominent
  property icon string
  property type
    enum button submit reset
  property disabled boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine button-machine
  role button

icon-button: kind
  description 'A button that shows only an icon; its label is the accessible name.'
  positional icon
  property icon string
  property label string
  property variant
    enum filled tonal outlined text bordered borderless prominent
  property type
    enum button submit reset
  property disabled boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine icon-button-machine
  role button

label: kind
  description 'The visible name of a form control.'
  positional value
  property value string
  property for element-ref
  property required boolean
  property style element-ref
  children none
  role none

link: kind
  description 'Goes to a URL or an element; javascript: URLs are rejected.'
  positional label
  property label string
  property href element-ref-or-url
  property external boolean
  property style element-ref
  property on action multi
  children none
  role link

text-field: kind
  description 'A single-line text input.'
  positional label
  property label string
  property variant
    enum filled outlined
  property name string
  property value string
  property placeholder string
  property type
    enum text email password search tel url
  property autocomplete string
  property required boolean
  property readonly boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine text-field-machine
  role textbox

text-area: kind
  description 'A multi-line text input.'
  positional label
  property label string
  property name string
  property value string
  property placeholder string
  property rows number
  property required boolean
  property readonly boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine text-area-machine
  role textbox

number-field: kind
  description 'A number input that steps with the arrow, Page, Home and End keys.'
  positional label
  property label string
  property name string
  property value number
  property min number
  property max number
  property step number
  property required boolean
  property readonly boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine number-field-machine
  role spinbutton
  property fallback number

color-field: kind
  description 'A hex colour text input with the native colour picker.'
  positional label
  property label string
  property name string
  property value color
  property required boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine color-field-machine
  role textbox
  property palette any

checkbox: kind
  description 'A box that is checked, unchecked or mixed.'
  positional label
  property label string
  property name string
  property value string
  property checked
    enum true false mixed
  property required boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine checkbox-machine
  role checkbox

radio-group: kind
  description 'A set of radio buttons with one tab stop; the arrows move and select.'
  positional label
  property label string
  property name string
  property value string
  property orientation
    enum vertical horizontal
  property required boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children any
  machine radio-group-machine
  role radiogroup

radio: kind
  description 'One choice of a radio group.'
  positional label
  property label string
  property value string
  property disabled boolean
  property style element-ref
  children none
  role radio

switch: kind
  description 'An on/off switch that applies at once.'
  positional label
  property label string
  property name string
  property value string
  property checked boolean
  property disabled boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine switch-machine
  role switch

slider: kind
  description 'Picks a number in a range by dragging or with the keyboard.'
  positional label
  property label string
  property name string
  property value number
  property min number
  property max number
  property step number
  property value-text string
  property orientation
    enum horizontal vertical
  property disabled boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine slider-machine
  role slider

select: kind
  description 'A select-only combobox: picks one option from a list.'
  positional label
  property label string
  property name string
  property value string
  property placeholder string
  property required boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children any
  machine select-machine
  role combobox
  property external-label boolean
  property aria-label string
  property aria-labelledby string
  property list-label string
  property list-labelledby string
  property menu-min-width number
  property menu-max-height number

combobox: kind
  description 'A text input that filters a list of options.'
  positional label
  property label string
  property name string
  property value string
  property placeholder string
  property required boolean
  property disabled boolean
  property invalid boolean
  property style element-ref
  property on action multi
  property bind any
  children any
  machine combobox-machine
  role combobox

option: kind
  description 'One option of a select or a combobox.'
  positional label
  property label string
  property value string
  property disabled boolean
  children none
  role option

progress: kind
  description 'Shows how far a task is, as a bar or a ring; without a value it is indeterminate.'
  positional label
  property label string
  property value number
  property max number
  property shape
    enum linear circular
  property style element-ref
  children none
  role progressbar

badge: kind
  description 'A short status text or count.'
  positional value
  property value string
  property label string
  property tone
    enum neutral primary error
  property style element-ref
  children none
  role none

avatar: kind
  description 'A picture of a person or thing, with initials when there is none.'
  positional name
  property name string
  property source url
  property size
    enum small medium large
  property style element-ref
  children none
  role img

chip: kind
  description 'A compact label, with an optional action that removes it.'
  positional label
  property label string
  property value string
  property variant
    enum filled outlined
  property tone
    enum neutral primary error
  property removable boolean
  property remove-label string
  property removed boolean
  property disabled boolean
  property style element-ref
  property on action multi
  property bind any
  children none
  machine chip-machine

accordion: kind
  description 'A heading that shows or hides its section (one disclosure); siblings form a group.'
  positional label
  property label string
  property open boolean
  property disabled boolean
  property heading-level number
  property style element-ref
  property on action multi
  property bind any
  children any
  machine disclosure-machine
  role region
`;
